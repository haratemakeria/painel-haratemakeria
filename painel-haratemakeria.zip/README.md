# Painel Hara Temakeria

Sistema em desenvolvimento para gerenciamento de pedidos, etapas e impressão.