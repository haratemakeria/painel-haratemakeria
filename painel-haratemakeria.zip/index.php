
<?php
echo "<h2>Painel Hara Temakeria</h2>";
echo "<p>Seja bem-vindo. Em breve, seu painel completo aparecerá aqui.</p>";
?>
